<?php

/**
 * Plugin Name:       Custom_Post  
 * Description:       Description of the plugin.
 */

// First create a custom post type name 'Movies'
// First create a custom post type name 'Movies'
 
function diwp_movies_custom_post_type(){
     
    // Set labels for custom post type
 
    $labels = array(
                     'name' => 'Movies',
                     'singular_name' => 'Movie',
                     'add_new'    => 'Add Movie',
                     'add_new_item' => 'Enter Movie Details',
                     'all_items' => 'All Movies',
                     'featured_image' => 'Add Featured Image',
                     'set_featured_image' => 'Set Featured Image',
                     'remove_featured_image' => 'Remove Poster Image',
                     'search_items'        => __( 'Search '),
                     'not_found'           => __( 'Not Found'),
                     'not_found_in_trash'  => __( 'Not found in Trash')
 
 
                   );
 
 
    // Set Options for this custom post type;
 
    $args = array(    
                    'public' => true,
                    'label'       => 'Movies',
                    'labels'      => $labels,
                    'supports'    => array( 'title', 'editor','author', 'thumbnail', 'revisions'), 
                    'supports'    => array( 'title', 'editor', 'thumbnail'),
                    'capability_type' => 'page',
                    'public'              => true,
                    'hierarchical'        => false,
                    'show_ui'             => true,
                    'show_in_menu'        => true,
                    'show_in_nav_menus'   => true,
                    'show_in_admin_bar'   => true,
                    'has_archive'         => true,
                    'taxonomies'          => array('post_tag','category'),
                    'capability_type'     => 'page',
                     
                 );
 
    register_post_type('movies', $args);
 
}
 
add_action( 'init', 'diwp_movies_custom_post_type' );
 
// Custom Post Type ends here.

// Create Shortcode to Display Movies Post Types
function diwp_create_shortcode_movies_post_type(){
 
    $args = array(
                    'post_type'      => 'movies',
                    'posts_per_page' => '10',
                    'publish_status' => 'published',
                 );
 
    $query = new WP_Query($args);
 
    if($query->have_posts()) :
 
        while($query->have_posts()) :
 
            $query->the_post() ;
                     
        $result .= '<div class="movie-item">';
        $result .= '<div class="movie-poster">' . get_the_post_thumbnail() . '</div>';
        $result .= '<div class="movie-name"><h2>' . get_the_title() . '</h2></div>';
        $result .= '<div class="movie-desc">' . get_the_content() . '</div>'; 
        $result .= '<div class="movie-desc">' . get_the_category() . '</div>';
        $result .= '</div>';
        endwhile;
        wp_reset_postdata();
        endif;    
    return $result;            
}
add_shortcode( 'movies-list', 'diwp_create_shortcode_movies_post_type' ); 
